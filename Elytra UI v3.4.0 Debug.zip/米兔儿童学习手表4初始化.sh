su
wm size 368x448
wm density 240